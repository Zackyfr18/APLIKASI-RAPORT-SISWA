<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->model('nilai_m');
        $this->load->model("siswa_m");
    }

    public function index()
    {
        $data['report'] = true;
        $data['content'] = 'report';
        $this->load->view('index',$data);
    }
    public function cetak()
    {
        $idtahun_akademik = $this->input->post('idtahun_akademik',true);
        $semester = $this->input->post('semester',true);
        $idkelas = $this->input->post('idkelas',true);
        $idguru = $this->input->post('idguru',true);
        $idsiswa = $this->input->post('idsiswa',true);
        $idnilai = $this->input->post('idnilai',true);
        $idmapel = $this->input->post('idmapel',true);
        $data['report_data'] = $this->nilai_m->getDataReport($idtahun_akademik,$semester,$idkelas,$idguru,$idsiswa);
        $data['report_wali'] = $this->nilai_m->getDataWali($idtahun_akademik,$semester,$idkelas);
        $data['report_guru'] = $this->nilai_m->getDataGuru($idtahun_akademik,$semester,$idkelas,$idguru);
        $data['report_nilai'] = $this->nilai_m->getDataNilai($idtahun_akademik,$semester,$idkelas,$idsiswa);
        //$data['report_nilai_per_mapel'] = $this->nilai_m->getDataNilaiPerMapel($idtahun_akademik, $semester, $idkelas, $idguru, $idsiswa, $idmapel);
        $data['report_nilai_per_kelas'] = $this->nilai_m->getDataNilaiPerKelas($idtahun_akademik, $semester, $idkelas);
        
        $this->load->view('cetak_report',$data);
    }
  

}

/* End of file Report.php */