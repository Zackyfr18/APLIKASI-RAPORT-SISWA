
<script>
    function printData() {
        var printContents = document.getElementById('print-section').innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }
</script>

<!-- Add a button to trigger the print function -->
<button onclick="printData()" class="btn btn-success btn-sm btn-flat" style="float:right;">
    <i class="fa fa-print"></i> Cetak Data
</button>

<!-- Add a hidden section to hold the printable content -->
<section id="print-section" style="display: none;">
    <h2>Data Nilai yang Telah Diinput</h2>
    <table class="table table-bordered table-hover">
        <!-- Include the table rows with the inputted data here -->
        <!-- Example: -->
        <tr>
            <th>Nama Siswa</th>
            <th>Nilai</th>
        </tr>
        <tr>
            <td>John Doe</td>
            <td>85</td>
        </tr>
    </table>
</section>