<?php
error_reporting(0);
?>
<html>

<head>
    <link rel="stylesheet" href="<?=base_url('assets/');?>bower_components/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet"
        href="<?=base_url('assets/');?>bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
    <script src="<?=base_url('assets/');?>bower_components/jquery/dist/jquery.min.js"></script>
    <script src="<?=base_url('assets/');?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?=base_url('assets/');?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?=base_url('assets/');?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <title>Cetak Laporan Nilai</title>
</head>

<body>

    <div style="page-break-after:always;">
        <br />
        <img src="<?=base_url('uploads/')._school_profile()->logo;?>" alt="Logo Sekolah"
            style="width:70px;height:70px;float:left;margin-bottom:10px;">
        <h3 style="line-height:5px;text-align:right;"><?=_school_profile()->nama;?></h3>
        <h3 style="line-height:5px;text-align:right;">Akreditasi <?=_school_profile()->akreditasi;?></h3>
        <hr style="border:1px solid;margin-right:0px;width:800px;">
        <hr style="border:0.5px solid;margin-top:-15px;margin-right:0px;width:750px;">
        <p style="line-height:5px;text-align:right;margin-top:-10px;">Alamat : <?=_school_profile()->alamat;?> RT
            <?=_school_profile()->rt;?> / RW
            <?=_school_profile()->rw;?>
            <?=_school_profile()->dusun;?>, Kel. <?=_school_profile()->kelurahan;?>, <?=_school_profile()->kecamatan;?>,
            <?=_school_profile()->kota;?> - <?=_school_profile()->provinsi;?></p>
        <br>
        <h4 class="text-center">DATA HASIL BELAJAR SISWA</h4>
        <h4 class="text-center">LAPORAN NILAI SISWA </h4>
        <br>
        <table style="padding:15px;">
            <tr>
                <td width="150"><b>NIP</b></td>
                <td width="20">:</td>
                <td width="350"><?=$report_guru['nip'];?></td>
                <td width="125"><b>Tahun Ajaran</b></td>
                <td width="20">:</td>
                <td><?=$report_data['tahun_akademik'];?></td>
            </tr>
            
            <tr>
                <td width="150"><b>Nama Guru</b></td>
                <td width="20">:</td>
                <td width="350"><?=$report_guru['nama'];?></td>
                <td width="125"><b>Semester</b></td>
                <td width="20">:</td>
                <td><?=$report_data['semester'];?></td>
            </tr>
            <tr>
            <td width="125"><b>Kelas</b></td>
                <td width="20">:</td>
                <td><?=$report_data['kelas_kd'];?></td>
                <tr>
                <td width="150"><b>Mata Pelajaran</b></td>
                <td width="20">:</td>
                <td width="350">
                <?php if (!empty($report_nilai_per_kelas)): ?>
                <?= $report_nilai_per_kelas[0]['mapel_nama']; ?>
                 <?php endif; ?>
            </td>
            </tr>
            </tr>
        </table>
        <h4 class="text-center">Nilai Siswa Per Mata Pelajaran</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nis</th>
                    <th>Nama Siswa</th>
                    <th>Mata Pelajaran</th>
                    <th>Nilai Akhir</th>
                    <th>Predikat</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($report_nilai_per_kelas as $row): ?>
                <tr>
                    <td><?= $row['nis']; ?></td>
                    <td><?= $row['nama_siswa']; ?></td>
                    <td><?= $row['mapel_nama']; ?></td>
                    <td class="text-center"><?= $row['nilai_akhir']; ?></td>
                    <td class="text-center"><?= $row['nilai_huruf']; ?></td>
                    <td><?= $row['deskripsi']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <p>
            Keterangan :
            <br>
            <b>RTP</b> : Rata-rata nilai Tugas/PR
            <br>
            <b>RNU</b> : Rata-rata nilai Ulangan Harian
            <br>
            <b>PTS</b> : Penilaian Tengah Semester
            <br>
            <b>UAS</b> : Ujian Akhir Semester
        </p>
        <p style="text-align:right;margin-right:125px;"><?=$report_data['tempat'];?>,
            <?=date('d M Y',strtotime($report_data['tanggal']));?></p>
        <table>
            <tr>
                <td class="text-center" width="500">
                    Kepala Sekolah
                    <br>
                    <?=_school_profile()->nama;?>
                    <br>
                    <br>
                    <br>
                    <br>
                    <u><?=_school_profile()->nama_kepsek;?></u>
                    <br>
                    NIP. <?=_school_profile()->nip_kepsek;?>
                </td>
            </tr>
        </table>
    </div>
</body>

</html>

<script>
window.print();
</script>